import os

class Config():

    SECRET_KEY ='20661143fd81501206948abe1df6ce38'
    SQLALCHEMY_DATABASE_URI ='sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False